/*
 * Copyright (C) 2005 Rob Manning
 * manningr@users.sourceforge.net
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package net.sourceforge.squirrel_sql.client.update;

import java.io.File;
import java.lang.reflect.Modifier;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.sourceforge.squirrel_sql.client.plugin.IPlugin;
import net.sourceforge.squirrel_sql.fw.util.MyURLClassLoader;
import net.sourceforge.squirrel_sql.fw.util.log.ILogger;

public class PluginClassLoader extends MyURLClassLoader {

    public PluginClassLoader(String[] pluginFiles) throws MalformedURLException
    {
        super(createURLs(pluginFiles));
    }    
    
    public PluginClassLoader(ArrayList files) throws MalformedURLException {
        super(createURLs(files));
    }
    
    public PluginClassLoader(URL[] urls) {
        super(urls);
    }

    public PluginClassLoader(URL url) {
        super(url);
    }
    
    public IPlugin[] getPluginClasses(ILogger logger)
    {
        final Class[] classes = getAssignableClasses(IPlugin.class, logger);
        final List list = new ArrayList();
        for (int i = 0; i < classes.length; ++i)
        {
            Class clazz = classes[i];
            if (!Modifier.isAbstract(clazz.getModifiers()))
            {
                try {
                    list.add(clazz.newInstance());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return (IPlugin[])list.toArray(new IPlugin[list.size()]);
    }    
    
    private static URL[] createURLs(String[] fileNames)
        throws MalformedURLException
    {
        if (fileNames == null)
        {
            fileNames = new String[0];
        }
        URL[] urls = new URL[fileNames.length];
        for (int i = 0; i < fileNames.length; ++i)
        {
            urls[i] = new File(fileNames[i]).toURL();
        }
        return urls;
    }    

    private static URL[] createURLs(ArrayList fileNames)
    throws MalformedURLException
    {
        if (fileNames == null)
        {
            fileNames = new ArrayList();
        }
        URL[] urls = new URL[fileNames.size()];
        int i = 0;
        for (Iterator iter = fileNames.iterator(); iter.hasNext(); i++) {
            String element = (String) iter.next();
            urls[i] = new File(element).toURL();
        }
        return urls;
    }        
    
    /**
     * @param args
     */
    public static void main(String[] args) throws Exception {
        //ApplicationArguments.initialize(new String[0]);
        PluginClassLoader cloader = new PluginClassLoader(args);
        IPlugin[] classes = cloader.getPluginClasses(null);
        for (int i = 0; i < classes.length; i++) {
            IPlugin plugin = classes[i];
            String name = plugin.getInternalName();
            String version = plugin.getVersion();
            System.out.println("name="+name+" version="+version);
        }
    }

}
