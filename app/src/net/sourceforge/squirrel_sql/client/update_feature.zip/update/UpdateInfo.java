/*
 * Copyright (C) 2005 Rob Manning
 * manningr@users.sourceforge.net
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package net.sourceforge.squirrel_sql.client.update;

import net.sourceforge.squirrel_sql.client.plugin.IPlugin;

public class UpdateInfo {

    private String _name = null;
    private String _availableVersion = null;
    private String _installedVersion = null;
    
    public UpdateInfo(String name, String availVersion, String installedVersion) {
        setName(name);
        setAvailableVersion(availVersion);
        setInstalledVersion(installedVersion);
    }

    public UpdateInfo(IPlugin plugin) {
        _name = plugin.getInternalName();
        _installedVersion = plugin.getVersion();
    }
    
    /**
     * @param _name The _name to set.
     */
    public void setName(String _name) {
        this._name = _name;
    }

    /**
     * @return Returns the _name.
     */
    public String getName() {
        return _name;
    }

    /**
     * @param _availableVersion The _availableVersion to set.
     */
    public void setAvailableVersion(String _availableVersion) {
        this._availableVersion = _availableVersion;
    }

    /**
     * @return Returns the _availableVersion.
     */
    public String getAvailableVersion() {
        return _availableVersion;
    }

    /**
     * @param _installedVersion The _installedVersion to set.
     */
    public void setInstalledVersion(String _installedVersion) {
        this._installedVersion = _installedVersion;
    }

    /**
     * @return Returns the _installedVersion.
     */
    public String getInstalledVersion() {
        return _installedVersion;
    }
    
    public String toString() {
        return _name + "-" + _installedVersion + "-" + _availableVersion;
    }
}
