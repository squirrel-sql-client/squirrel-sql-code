/*
 * Copyright (C) 2005 Rob Manning
 * manningr@users.sourceforge.net
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package net.sourceforge.squirrel_sql.client.update;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import net.sourceforge.squirrel_sql.client.ApplicationArguments;
import net.sourceforge.squirrel_sql.client.Version;
import net.sourceforge.squirrel_sql.client.plugin.IPlugin;

public class UpdateController {

    private String repositoryLoc = 
        "http://squirrel-sql.sourceforge.net/release";
    
    private HashMap updateInfoMap = new HashMap();
    
    //private String squirrelHomeDir = System.getProperty("user.dir");
    private String squirrelHomeDir = null;
    
    public UpdateController(String homeDir) throws MalformedURLException {
        squirrelHomeDir = homeDir;
        initialize();
    }
    
    /**
     * @param args
     */
    public static void main(String[] args) throws Exception {
        ApplicationArguments.initialize(new String[0]);
        UpdateController c = new UpdateController("C:\\tools\\squirrel");
    }

    private void initialize() throws MalformedURLException {
        readLocalVersions();
    }
    
    /**
     * This will examine the local installation and determine what plugins are
     * installed, and what their version is.
     *
     */
    private void readLocalVersions() throws MalformedURLException {
        UpdateInfo coreInfo = new UpdateInfo("Core", null, Version.getShortVersion());
        updateInfoMap.put("Core", coreInfo);
        ArrayList pluginFiles = getLocalPluginJars(squirrelHomeDir);
        for (Iterator iter = pluginFiles.iterator(); iter.hasNext();) {
            String element = (String) iter.next();
            URL url = new File(element).toURL();
            PluginClassLoader cloader = new PluginClassLoader(url);
            IPlugin[] plugins = cloader.getPluginClasses(null);
            for (int i = 0; i < plugins.length; i++) {
                IPlugin plugin = plugins[i];
                UpdateInfo pluginInfo = new UpdateInfo(plugin);
                updateInfoMap.put(plugin.getInternalName(), pluginInfo);
                System.out.println("plugin: "+pluginInfo);
            }
        }
        
        PluginClassLoader cloader = new PluginClassLoader(pluginFiles);
        IPlugin[] plugins = cloader.getPluginClasses(null);
        for (int i = 0; i < plugins.length; i++) {
            IPlugin plugin = plugins[i];
            UpdateInfo pluginInfo = new UpdateInfo(plugin);
            updateInfoMap.put(plugin.getInternalName(), pluginInfo);
            System.out.println("plugin: "+pluginInfo);
        }
    }
    
    private ArrayList getLocalPluginJars(String installDir) {
        File f = new File(installDir + File.separator + "plugins");
        String[] fileList = f.list();
        ArrayList pluginFiles = new ArrayList();
        for (int i = 0; i < fileList.length; i++) {
            String string = fileList[i];
            if (string.endsWith(".jar")) {
                pluginFiles.add(string);
                System.out.println("Found jar: "+string);
            }
        }
        return pluginFiles;
    }
}
